const grid = 16
let canvas, context
let count = 0
let userSpeed = 6

let snake = {
  dx: grid,
  dy: 0,
  x: 160,
  y: 160,
  cells: [],
  maxCells: 1,
}

let apple = {
  x: 176,
  y: 176,
}